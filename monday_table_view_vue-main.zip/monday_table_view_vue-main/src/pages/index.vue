<template>
  <Main />
</template>

<script lang="ts" setup>
  //
</script>
